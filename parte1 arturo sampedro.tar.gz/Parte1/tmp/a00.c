// Ejemplo sencillo del uso de operadores aritmeticos
{ int a;
  
  read(a); 
  print((((a + a) * 4) % 3) - ((3 * a) / 3));
  print(b);
}
